latexcv/modern
=======

Introduction
------------

A modern cv / resume written in latex.


License
-------

The MIT License (MIT)

Credits
-------

Jan Küster
www.jankuester.com
